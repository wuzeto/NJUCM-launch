#include<iostream>
using namespace std;
template<class T>
class Wrapper{
 T a;
 public:
     Wrapper(const T a):a(a){}
     T get()const{return a;}
     void set(const T a);
};
template<class T>
void Wrapper<T>::set(const T a){this->a=a;}
int main(){
Wrapper<string>c1("A");
Wrapper<int>i1(12);
cout<<c1.get()<<endl;
cout<<i1.get()<<endl;
return 0;
}
