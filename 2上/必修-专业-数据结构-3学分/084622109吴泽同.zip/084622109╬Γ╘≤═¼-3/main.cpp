#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

// ������
void rotate1(int arr[], int n, int k) {
    for (int i = 0; i < k; i++) {
        int temp = arr[0];
        for (int j = 1; j < n; j++) {
            arr[j - 1] = arr[j];
        }
        arr[n - 1] = temp;
    }
}

// ��ת��
void reverse(int arr[], int begin, int end) {
    while (begin < end) {
        swap(arr[begin], arr[end]);
        begin++;
        end--;
    }
}
void rotate2(int arr[], int n, int k) {
    reverse(arr, 0, n-1);
    reverse(arr, 0, k-1);
    reverse(arr, k, n-1);
}
int gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}

// ��״�滻��
void rotate3(int arr[], int n, int k) {
    k = k % n;
    int count = gcd(n, k);
    for (int i = 0; i < count; i++) {
        int j = i;
        int temp = arr[i];
        while ((j + k) % n != i) {
            arr[j] = arr[(j + k) % n];
            j = (j + k) % n;
        }
        arr[j] = temp;
    }
}


// �����������
void generateRandomArray(int arr[], int n) {
    srand((unsigned int)(time(NULL)));
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 10000;
    }
}

// ��ӡ����
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    const int n = 100;
    int k = 30;
    int arr1[n], arr2[n], arr3[n];

    generateRandomArray(arr1, n);
    copy(arr1, arr1+n, arr2);
    copy(arr1, arr1+n, arr3);
    //cout << "Original array: ";
    //printArray(arr1, n);

    // ����������
    clock_t start = clock();
    for(int m=1;m<10e4;m++)
    rotate1(arr1, n, k);
    clock_t endi = clock();
    //cout << "Rotated array (brute force): ";
    //printArray(arr1, n);
    cout << "Time taken by������: " << double(endi - start) / CLOCKS_PER_SEC << endl;

    // ��ת������
    start = clock();
    for(int m=1;m<10e4;m++)
    rotate2(arr2, n, k);
    endi = clock();
    //cout << "Rotated array (reverse): ";
    //printArray(arr2, n);
    cout << "Time taken by��ת��: " << double(endi - start) / CLOCKS_PER_SEC << endl;

    // ��״�滻������
    start = clock();
    for(int m=1;m<10e4;m++)
    rotate3(arr3, n, k);
    endi = clock();
    //cout << "Rotated array (cyclic replacements): ";
    //printArray(arr3, n);
    cout << "Time taken by��״�滻��: " << double(endi - start) / CLOCKS_PER_SEC << endl;

    return 0;
}
